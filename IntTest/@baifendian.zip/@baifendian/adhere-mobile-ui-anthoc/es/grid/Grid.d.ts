import { Grid } from 'antd-mobile';
import type { GridProps } from 'antd-mobile';
declare const GridHOC: typeof Grid & {
    defaultProps?: Partial<GridProps>;
};
export default GridHOC;
