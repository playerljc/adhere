import type { FC } from 'react';
import type { ListCheckAllProps } from './types';
declare const ListCheckAll: FC<ListCheckAllProps>;
export default ListCheckAll;
