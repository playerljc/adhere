import { JumboTabs } from 'antd-mobile';
import type { JumboTabsProps } from 'antd-mobile';
declare const JumboTabsHOC: typeof JumboTabs & {
    defaultProps?: Partial<JumboTabsProps>;
};
export default JumboTabsHOC;
