import JumboTabs from './JumboTabs';
export default JumboTabs;
