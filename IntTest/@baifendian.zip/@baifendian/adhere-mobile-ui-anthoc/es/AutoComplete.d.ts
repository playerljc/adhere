import type { FC } from 'react';
import type { AutoCompleteProps } from './types';
declare const AutoComplete: FC<AutoCompleteProps>;
export default AutoComplete;
