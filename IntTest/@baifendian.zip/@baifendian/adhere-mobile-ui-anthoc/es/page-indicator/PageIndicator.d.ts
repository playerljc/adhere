import { PageIndicator } from 'antd-mobile';
import type { PageIndicatorProps } from 'antd-mobile';
declare const PageIndicatorHOC: typeof PageIndicator & {
    defaultProps?: Partial<PageIndicatorProps>;
};
export default PageIndicatorHOC;
