import PageIndicator from './PageIndicator';
export default PageIndicator;
