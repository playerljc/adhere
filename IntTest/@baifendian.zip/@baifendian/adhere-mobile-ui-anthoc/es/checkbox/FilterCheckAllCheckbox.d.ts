import React from 'react';
import type { DisplayNameInternal, FilterCheckAllCheckboxProps } from '../types';
declare const FilterCheckAllCheckbox: DisplayNameInternal<React.NamedExoticComponent<FilterCheckAllCheckboxProps>>;
export default FilterCheckAllCheckbox;
