import type { FC } from 'react';
import type { CheckboxGroupProps } from '../types';
declare const InternalCheckbox: FC<CheckboxGroupProps>;
export default InternalCheckbox;
