import React from 'react';
import type { FilterPagingCheckboxProps } from '../types';
import { DisplayNameInternal } from '../types';
declare const FilterPagingCheckbox: DisplayNameInternal<React.NamedExoticComponent<FilterPagingCheckboxProps>>;
export default FilterPagingCheckbox;
