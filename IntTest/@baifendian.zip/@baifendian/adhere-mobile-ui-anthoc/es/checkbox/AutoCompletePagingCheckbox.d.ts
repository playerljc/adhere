import React from 'react';
import { AutoCompletePagingCheckboxProps, DisplayNameInternal } from '../types';
declare const AutoCompletePagingCheckbox: DisplayNameInternal<React.NamedExoticComponent<AutoCompletePagingCheckboxProps>>;
export default AutoCompletePagingCheckbox;
