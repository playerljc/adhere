import type { CheckboxHOCComponent } from '../types';
declare const CheckboxHOC: CheckboxHOCComponent;
export default CheckboxHOC;
