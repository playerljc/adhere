import React from 'react';
import type { DisplayNameInternal, FilterCheckboxProps } from '../types';
declare const FilterCheckBox: DisplayNameInternal<React.NamedExoticComponent<FilterCheckboxProps>>;
export default FilterCheckBox;
