import React from 'react';
import type { AutoCompleteCheckboxProps, DisplayNameInternal } from '../types';
declare const AutoCompleteCheckbox: DisplayNameInternal<React.NamedExoticComponent<AutoCompleteCheckboxProps>>;
export default AutoCompleteCheckbox;
