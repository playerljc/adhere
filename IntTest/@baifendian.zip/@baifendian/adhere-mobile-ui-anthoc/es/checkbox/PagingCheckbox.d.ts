import React from 'react';
import type { DisplayNameInternal, PagingCheckboxProps } from '../types';
declare const PagingCheckbox: DisplayNameInternal<React.NamedExoticComponent<PagingCheckboxProps>>;
export default PagingCheckbox;
