import React from 'react';
import type { CheckAllCheckboxProps, DisplayNameInternal } from '../types';
declare const CheckAllCheckBox: DisplayNameInternal<React.NamedExoticComponent<CheckAllCheckboxProps>>;
export default CheckAllCheckBox;
