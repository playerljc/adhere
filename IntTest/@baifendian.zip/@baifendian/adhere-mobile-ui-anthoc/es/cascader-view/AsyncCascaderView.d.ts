import React from 'react';
import type { AsyncCascaderViewProps, DisplayNameInternal } from '../types';
declare const AsyncCascaderView: DisplayNameInternal<React.NamedExoticComponent<AsyncCascaderViewProps>>;
export default AsyncCascaderView;
