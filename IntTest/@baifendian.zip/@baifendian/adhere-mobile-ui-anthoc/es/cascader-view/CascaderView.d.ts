import type { CascaderViewHOCComponent } from '../types';
declare const CascaderViewHOC: CascaderViewHOCComponent;
export default CascaderViewHOC;
