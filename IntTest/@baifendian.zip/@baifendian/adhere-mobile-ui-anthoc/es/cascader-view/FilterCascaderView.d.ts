import React from 'react';
import type { DisplayNameInternal, FilterCascaderViewProps } from '../types';
declare const FilterCascaderView: DisplayNameInternal<React.NamedExoticComponent<FilterCascaderViewProps>>;
export default FilterCascaderView;
