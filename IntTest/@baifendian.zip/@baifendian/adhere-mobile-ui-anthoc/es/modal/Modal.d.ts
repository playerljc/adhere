import type { ModalHOCComponent } from '../types';
declare const ModalHOC: ModalHOCComponent;
export default ModalHOC;
