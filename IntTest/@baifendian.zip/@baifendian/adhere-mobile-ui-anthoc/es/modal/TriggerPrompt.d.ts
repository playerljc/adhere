import React from 'react';
import type { DisplayNameInternal, ModalTriggerPromptProps } from '../types';
declare const ModalTriggerPrompt: DisplayNameInternal<React.NamedExoticComponent<ModalTriggerPromptProps<any>>>;
export default ModalTriggerPrompt;
