import React from 'react';
import type { DisplayNameInternal, ModalTriggerProps } from '../types';
declare const ModalTrigger: DisplayNameInternal<React.NamedExoticComponent<ModalTriggerProps<any>>>;
export default ModalTrigger;
