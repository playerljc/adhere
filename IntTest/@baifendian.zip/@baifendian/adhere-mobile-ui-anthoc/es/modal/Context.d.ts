import React from 'react';
import type { ModalTriggerContext } from '../types';
declare const _default: React.Context<ModalTriggerContext>;
export default _default;
