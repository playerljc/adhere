import { NoticeBar } from 'antd-mobile';
import type { NoticeBarProps } from 'antd-mobile';
declare const NoticeBarHOC: typeof NoticeBar & {
    defaultProps?: Partial<NoticeBarProps>;
};
export default NoticeBarHOC;
