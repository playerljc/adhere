import NoticeBar from './NoticeBar';
export default NoticeBar;
