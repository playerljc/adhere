import DotLoading from './DotLoading';
export default DotLoading;
