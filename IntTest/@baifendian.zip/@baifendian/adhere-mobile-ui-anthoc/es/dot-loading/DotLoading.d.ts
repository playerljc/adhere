import { DotLoading } from 'antd-mobile';
import type { DotLoadingProps } from 'antd-mobile';
declare const DotLoadingHOC: typeof DotLoading & {
    defaultProps?: Partial<DotLoadingProps>;
};
export default DotLoadingHOC;
