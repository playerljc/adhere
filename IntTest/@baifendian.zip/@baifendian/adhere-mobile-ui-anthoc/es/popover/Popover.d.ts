import { Popover } from 'antd-mobile';
import type { PopoverProps } from 'antd-mobile';
declare const PopoverHOC: typeof Popover & {
    defaultProps?: Partial<PopoverProps>;
};
export default PopoverHOC;
