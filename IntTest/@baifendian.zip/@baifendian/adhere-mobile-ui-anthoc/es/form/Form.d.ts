import type { FormHOCComponent } from '../types';
declare const FormHOC: FormHOCComponent;
export default FormHOC;
