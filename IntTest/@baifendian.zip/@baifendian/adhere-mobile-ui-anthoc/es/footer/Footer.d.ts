import { Footer } from 'antd-mobile';
import type { FooterProps } from 'antd-mobile';
declare const FooterHOC: typeof Footer & {
    defaultProps?: Partial<FooterProps>;
};
export default FooterHOC;
