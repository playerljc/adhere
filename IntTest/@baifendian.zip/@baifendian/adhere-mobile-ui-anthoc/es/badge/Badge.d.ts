import { Badge } from 'antd-mobile';
import type { BadgeProps } from 'antd-mobile';
declare const BadgeHOC: typeof Badge & {
    defaultProps?: Partial<BadgeProps>;
};
export default BadgeHOC;
