import type { FC } from 'react';
import type { RangeCalendarPopupProps } from '../types';
declare const RangeCalendarPopup: FC<RangeCalendarPopupProps>;
export default RangeCalendarPopup;
