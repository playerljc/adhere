import React from 'react';
import type { CalendarPopupProps } from '../types';
declare const InternalCalendarPopup: React.NamedExoticComponent<CalendarPopupProps>;
export default InternalCalendarPopup;
