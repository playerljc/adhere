import type { CalendarPopupHOCComponent } from '../types';
declare const CalendarPopupHOC: CalendarPopupHOCComponent;
export default CalendarPopupHOC;
