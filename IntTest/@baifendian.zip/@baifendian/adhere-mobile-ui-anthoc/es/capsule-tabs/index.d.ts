import CapsuleTabs from './CapsuleTabs';
export default CapsuleTabs;
