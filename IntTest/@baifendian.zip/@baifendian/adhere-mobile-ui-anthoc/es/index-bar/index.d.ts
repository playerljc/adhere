import IndexBar from './IndexBar';
export default IndexBar;
