import { IndexBar } from 'antd-mobile';
import type { IndexBarProps } from 'antd-mobile';
declare const IndexBarHOC: typeof IndexBar & {
    defaultProps?: Partial<IndexBarProps>;
};
export default IndexBarHOC;
