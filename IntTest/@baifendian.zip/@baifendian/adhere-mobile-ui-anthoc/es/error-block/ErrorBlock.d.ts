import { ErrorBlock } from 'antd-mobile';
import type { ErrorBlockProps } from 'antd-mobile';
declare const ErrorBlockHOC: typeof ErrorBlock & {
    defaultProps?: Partial<ErrorBlockProps>;
};
export default ErrorBlockHOC;
