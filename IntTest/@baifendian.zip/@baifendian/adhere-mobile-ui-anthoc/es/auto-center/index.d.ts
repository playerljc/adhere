import AutoCenter from './AutoCenter';
export default AutoCenter;
