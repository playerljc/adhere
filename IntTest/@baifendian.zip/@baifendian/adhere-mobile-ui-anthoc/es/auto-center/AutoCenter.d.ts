import { AutoCenter } from 'antd-mobile';
import type { AutoCenterProps } from 'antd-mobile';
declare const AutoCenterHOC: typeof AutoCenter & {
    defaultProps?: Partial<AutoCenterProps>;
};
export default AutoCenterHOC;
