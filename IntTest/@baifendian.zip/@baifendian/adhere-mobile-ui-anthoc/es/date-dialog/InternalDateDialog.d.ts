import React from 'react';
import type { DateDialogProps } from '../types';
declare const InternalDateDialog: React.NamedExoticComponent<DateDialogProps>;
export default InternalDateDialog;
