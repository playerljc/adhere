import { Divider } from 'antd-mobile';
import type { DividerProps } from 'antd-mobile';
declare const DividerHOC: typeof Divider & {
    defaultProps?: Partial<DividerProps>;
};
export default DividerHOC;
