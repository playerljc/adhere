import DateFormatValueHOC from './DateFormatValueHOC';
export default DateFormatValueHOC;
