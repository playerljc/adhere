import React from 'react';
import type { DisplayNameInternal, PagingCheckboxCheckListProps } from '../types';
declare const PagingCheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<PagingCheckboxCheckListProps>>;
export default PagingCheckboxCheckList;
