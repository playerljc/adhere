import React from 'react';
import type { FilterPagingCheckListProps } from '../types';
import { DisplayNameInternal } from '../types';
declare const FilterPagingCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterPagingCheckListProps>>;
export default FilterPagingCheckList;
