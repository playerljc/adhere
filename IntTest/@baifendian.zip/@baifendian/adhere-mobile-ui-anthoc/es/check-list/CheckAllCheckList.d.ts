import React from 'react';
import type { CheckAllCheckListProps, DisplayNameInternal } from '../types';
declare const CheckAllCheckList: DisplayNameInternal<React.NamedExoticComponent<CheckAllCheckListProps>>;
export default CheckAllCheckList;
