import React from 'react';
import type { DisplayNameInternal, PagingCheckListProps } from '../types';
declare const PagingCheckList: DisplayNameInternal<React.NamedExoticComponent<PagingCheckListProps>>;
export default PagingCheckList;
