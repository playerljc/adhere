import React from 'react';
import type { CheckboxCheckListProps, DisplayNameInternal } from '../types';
declare const CheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<CheckboxCheckListProps>>;
export default CheckboxCheckList;
