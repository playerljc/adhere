import React from 'react';
import type { FilterPagingCheckboxCheckListProps } from '../types';
import { DisplayNameInternal } from '../types';
declare const FilterPagingCheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterPagingCheckboxCheckListProps>>;
export default FilterPagingCheckboxCheckList;
