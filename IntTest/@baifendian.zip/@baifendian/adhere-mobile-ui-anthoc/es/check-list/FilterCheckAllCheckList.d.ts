import React from 'react';
import type { DisplayNameInternal, FilterCheckAllCheckListProps } from '../types';
declare const FilterCheckAllCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterCheckAllCheckListProps>>;
export default FilterCheckAllCheckList;
