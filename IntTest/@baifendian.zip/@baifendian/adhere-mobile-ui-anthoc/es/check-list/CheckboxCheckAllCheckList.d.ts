import React from 'react';
import type { CheckboxCheckAllCheckListProps, DisplayNameInternal } from '../types';
declare const CheckboxCheckAllCheckList: DisplayNameInternal<React.NamedExoticComponent<CheckboxCheckAllCheckListProps>>;
export default CheckboxCheckAllCheckList;
