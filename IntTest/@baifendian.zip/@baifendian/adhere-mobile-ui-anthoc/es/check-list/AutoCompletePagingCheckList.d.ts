import React from 'react';
import type { AutoCompletePagingCheckListProps, DisplayNameInternal } from '../types';
declare const AutoCompletePagingCheckList: DisplayNameInternal<React.NamedExoticComponent<AutoCompletePagingCheckListProps>>;
export default AutoCompletePagingCheckList;
