import React from 'react';
import type { AutoCompletePagingCheckboxCheckListProps, DisplayNameInternal } from '../types';
declare const AutoCompletePagingCheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<AutoCompletePagingCheckboxCheckListProps>>;
export default AutoCompletePagingCheckboxCheckList;
