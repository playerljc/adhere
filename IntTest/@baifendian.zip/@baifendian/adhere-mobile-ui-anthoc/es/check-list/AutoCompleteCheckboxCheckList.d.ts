import React from 'react';
import type { AutoCompleteCheckboxCheckListProps, DisplayNameInternal } from '../types';
declare const AutoCompleteCheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<AutoCompleteCheckboxCheckListProps>>;
export default AutoCompleteCheckboxCheckList;
