import type { CheckListHOCComponent } from '../types';
declare const CheckListHOC: CheckListHOCComponent;
export default CheckListHOC;
