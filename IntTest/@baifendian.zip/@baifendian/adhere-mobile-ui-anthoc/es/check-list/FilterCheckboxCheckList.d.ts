import React from 'react';
import type { DisplayNameInternal, FilterCheckboxCheckListProps } from '../types';
declare const FilterCheckboxCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterCheckboxCheckListProps>>;
export default FilterCheckboxCheckList;
