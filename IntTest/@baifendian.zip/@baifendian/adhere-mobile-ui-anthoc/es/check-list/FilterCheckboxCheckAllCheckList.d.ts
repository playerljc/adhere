import React from 'react';
import type { DisplayNameInternal, FilterCheckboxCheckAllCheckListProps } from '../types';
declare const FilterCheckboxCheckAllCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterCheckboxCheckAllCheckListProps>>;
export default FilterCheckboxCheckAllCheckList;
