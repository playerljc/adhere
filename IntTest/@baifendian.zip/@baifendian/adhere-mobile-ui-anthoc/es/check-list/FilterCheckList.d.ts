import React from 'react';
import type { FilterCheckListProps } from '../types';
import { DisplayNameInternal } from '../types';
declare const FilterCheckList: DisplayNameInternal<React.NamedExoticComponent<FilterCheckListProps>>;
export default FilterCheckList;
