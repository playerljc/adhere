import type { FC } from 'react';
import type { CheckListProps } from '../types';
/**
 * InternalCheckList
 * @param options
 * @param props
 * @constructor
 */
declare const InternalCheckList: FC<CheckListProps>;
export default InternalCheckList;
