import React from 'react';
import type { AutoCompleteCheckListProps, DisplayNameInternal } from '../types';
declare const AutoCompleteCheckList: DisplayNameInternal<React.NamedExoticComponent<AutoCompleteCheckListProps>>;
export default AutoCompleteCheckList;
