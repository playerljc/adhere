import type { FC } from 'react';
import type { RangeCalendarModalProps } from '../types';
declare const RangeCalendarModal: FC<RangeCalendarModalProps>;
export default RangeCalendarModal;
