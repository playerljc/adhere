import type { CalendarModalHOCComponent } from '../types';
declare const CalendarModalHOC: CalendarModalHOCComponent;
export default CalendarModalHOC;
