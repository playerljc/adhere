import React from 'react';
import type { CalendarModalProps } from '../types';
declare const InternalCalendarModal: React.NamedExoticComponent<CalendarModalProps>;
export default InternalCalendarModal;
