import { Input } from 'antd-mobile';
import type { InputProps } from 'antd-mobile';
declare const InputHOC: typeof Input & {
    defaultProps?: Partial<InputProps>;
};
export default InputHOC;
