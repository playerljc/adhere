import NumberKeyboard from './NumberKeyboard';
export default NumberKeyboard;
