import ConfigProvider from './ConfigProvider';
export default ConfigProvider;
