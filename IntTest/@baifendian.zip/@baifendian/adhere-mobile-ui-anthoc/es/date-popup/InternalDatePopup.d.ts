import React from 'react';
import type { DatePopupProps } from '../types';
declare const InternalDatePopup: React.NamedExoticComponent<DatePopupProps>;
export default InternalDatePopup;
