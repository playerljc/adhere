import React from 'react';
import type { DialogTriggerProps, DisplayNameInternal } from '../types';
declare const DialogTrigger: DisplayNameInternal<React.NamedExoticComponent<DialogTriggerProps<any>>>;
export default DialogTrigger;
