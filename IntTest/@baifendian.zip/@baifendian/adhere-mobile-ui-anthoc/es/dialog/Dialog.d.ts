import type { DialogHOCComponent } from '../types';
declare const DialogHOC: DialogHOCComponent;
export default DialogHOC;
