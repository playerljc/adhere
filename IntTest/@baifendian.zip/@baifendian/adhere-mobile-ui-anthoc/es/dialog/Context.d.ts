import React from 'react';
import type { DialogTriggerContext } from '../types';
declare const _default: React.Context<DialogTriggerContext>;
export default _default;
