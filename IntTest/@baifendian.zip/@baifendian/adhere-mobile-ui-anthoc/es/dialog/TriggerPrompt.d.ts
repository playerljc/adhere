import React from 'react';
import type { DialogTriggerPromptProps, DisplayNameInternal } from '../types';
declare const DialogTriggerPrompt: DisplayNameInternal<React.NamedExoticComponent<DialogTriggerPromptProps<any>>>;
export default DialogTriggerPrompt;
