import React from 'react';
import type { DateModalProps } from '../types';
declare const InternalDateModal: React.NamedExoticComponent<DateModalProps>;
export default InternalDateModal;
