import { CascadePicker } from 'antd-mobile';
import type { CascadePickerProps } from 'antd-mobile';
declare const CascadePickerHOC: typeof CascadePicker & {
    defaultProps?: Partial<CascadePickerProps>;
};
export default CascadePickerHOC;
