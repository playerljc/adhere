import FloatingBubble from './FloatingBubble';
export default FloatingBubble;
