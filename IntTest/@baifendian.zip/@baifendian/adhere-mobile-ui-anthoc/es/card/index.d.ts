import Card from './Card';
export default Card;
