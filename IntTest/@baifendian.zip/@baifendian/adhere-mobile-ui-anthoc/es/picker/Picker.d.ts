import { Picker } from 'antd-mobile';
import type { PickerProps } from 'antd-mobile';
declare const PickerHOC: typeof Picker & {
    defaultProps?: Partial<PickerProps>;
};
export default PickerHOC;
