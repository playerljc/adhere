import { Ellipsis } from 'antd-mobile';
import type { EllipsisProps } from 'antd-mobile';
declare const EllipsisHOC: typeof Ellipsis & {
    defaultProps?: Partial<EllipsisProps>;
};
export default EllipsisHOC;
