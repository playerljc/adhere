import type { InputProps } from 'antd-mobile';
import Input from '../input';
declare const InputNumberHOC: typeof Input & {
    defaultProps?: Partial<InputProps>;
};
export default InputNumberHOC;
