import FloatingPanel from './FloatingPanel';
export default FloatingPanel;
