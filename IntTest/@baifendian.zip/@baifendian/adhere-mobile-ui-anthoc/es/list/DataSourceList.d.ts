import React from 'react';
import type { DataSourceListProps, DisplayNameInternal } from '../types';
declare const DataSourceList: DisplayNameInternal<React.NamedExoticComponent<DataSourceListProps>>;
export default DataSourceList;
