import type { ListHOCComponent } from '../types';
declare const ListHOC: ListHOCComponent;
export default ListHOC;
