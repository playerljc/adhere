import { Empty } from 'antd-mobile';
import type { EmptyProps } from 'antd-mobile';
declare const EmptyHOC: typeof Empty & {
    defaultProps?: Partial<EmptyProps>;
};
export default EmptyHOC;
