import React from 'react';
import type { CalendarDialogProps } from '../types';
declare const InternalCalendarDialog: React.NamedExoticComponent<CalendarDialogProps>;
export default InternalCalendarDialog;
