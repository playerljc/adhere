import type { FC } from 'react';
import type { RangeCalendarDialogProps } from '../types';
declare const RangeCalendarDialog: FC<RangeCalendarDialogProps>;
export default RangeCalendarDialog;
