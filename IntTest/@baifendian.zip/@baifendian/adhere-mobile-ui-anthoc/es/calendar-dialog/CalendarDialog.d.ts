import type { CalendarDialogHOCComponent } from '../types';
declare const CalendarDialogHOC: CalendarDialogHOCComponent;
export default CalendarDialogHOC;
