export default Model;
import Model from '@baifendian/adhere-util-iframeio/es';
