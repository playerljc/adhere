export default Model;
import Model from '@baifendian/adhere-ui-fieldgeneratortodict/es';
