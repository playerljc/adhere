export default Model;
import Model from '@baifendian/adhere-mobile-ui-prompt-warnprompt/es';
