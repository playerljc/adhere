export default Model;
import Model from '@baifendian/adhere-mobile-ui-tabs/es';
