export default Model;
import Model from '@baifendian/adhere-mobile-ui-confirm-importantconfirm/es';
