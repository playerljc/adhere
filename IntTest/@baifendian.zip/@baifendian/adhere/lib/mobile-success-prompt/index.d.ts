export default Model;
import Model from '@baifendian/adhere-mobile-ui-prompt-successprompt/lib';
