export default Model;
import Model from '@baifendian/adhere-ui-space/lib';
