# 1.0.7

***

2021-08-09

* 加入PolygonSelection(多边形选区)组件
