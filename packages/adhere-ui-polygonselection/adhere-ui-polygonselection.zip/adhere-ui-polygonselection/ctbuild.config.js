module.exports = {
  getConfig({ webpackConfig }) {},
};
