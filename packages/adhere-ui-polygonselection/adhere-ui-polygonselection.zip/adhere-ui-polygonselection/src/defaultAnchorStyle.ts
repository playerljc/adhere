/**
 * 修改的时候控制点的样式
 */
export default {
  fillStyle: 'red',
  // 描边颜色
  strokeStyle: 'blue',
  // 描边大小
  lineWidth: 2,
  lineCap: 'round',
  lineJoin: 'round',
  lineDash: [5, 4, 3],
  lineDashOffset: -1,
  globalAlpha: 1,
};
