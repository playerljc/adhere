/**
 * 几何图形默认的样式
 */
export default {
  fillStyle: 'yellow',
  // 描边颜色
  strokeStyle: '#ccc',
  // 描边大小
  lineWidth: 30,
  lineCap: 'round',
  lineJoin: 'round',
  lineDash: [],
  lineDashOffset: -1,
};
