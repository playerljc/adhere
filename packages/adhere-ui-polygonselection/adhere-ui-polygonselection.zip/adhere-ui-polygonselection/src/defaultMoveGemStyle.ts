/**
 * 移动的元素样式
 */
export default {
  // 描边颜色
  strokeStyle: 'green',
  // 描边大小
  lineWidth: 2,
  lineDash: [5, 4, 3],
  lineDashOffset: -1,
  globalAlpha: 0.6,
};
