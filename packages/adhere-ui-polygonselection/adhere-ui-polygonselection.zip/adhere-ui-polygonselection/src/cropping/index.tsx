import { Button } from 'antd';
import classNames from 'classnames';
import React, { forwardRef, memo, useCallback, useRef } from 'react';
import type { ForwardRefRenderFunction } from 'react';

import MessageDialog from '@baifendian/adhere-ui-messagedialog';
import Intl from '@baifendian/adhere-util-intl';

import { CroppingCoreHandle, CroppingHandle, CroppingProps } from '../types';
import CroppingCore from './CroppingCore';

const selectorPrefix = 'adhere-ui-polygonselection-cropping';

/**
 * ForwardRefRenderFunction
 * @param props
 * @param ref
 * @constructor
 */
const Cropping: ForwardRefRenderFunction<CroppingHandle, CroppingProps> = (
  { className, style, value, onChange, modalProps, coreProps },
  ref,
) => {
  const coreRef = useRef<CroppingCoreHandle>();

  const renderMask = useCallback(
    () => (
      <div
        className={`${selectorPrefix}-mask`}
        onClick={() => {
          const dialog = MessageDialog.Modal({
            config: {
              title: Intl.v('编辑'),
              width: '60%',
              maskClosable: false,
              footer: [
                <Button
                  key="submit"
                  type="primary"
                  title={Intl.v('保存')}
                  onClick={() => {
                    if (!coreRef.current) return;

                    const base64 = coreRef.current.save();

                    if (onChange) {
                      onChange(base64);
                      dialog.close();
                    }
                  }}
                >
                  {Intl.v('保存')}
                </Button>,
              ],
              ...(modalProps || {}),
            },
            children: <CroppingCore ref={coreRef} {...coreProps} />,
          });
        }}
      >
        {Intl.v('编辑')}
      </div>
    ),
    [value, onChange],
  );

  const renderInner = useCallback(() => {
    return value ? <img src={value} alt="" /> : null;
  }, [value]);

  return (
    <div className={classNames(selectorPrefix, className || '')} style={style || {}}>
      {renderMask()}
      {renderInner()}
    </div>
  );
};

const CroppingHOC = memo(forwardRef<CroppingHandle, CroppingProps>(Cropping));

CroppingHOC.CroppingCore = CroppingCore;

export default CroppingHOC;
