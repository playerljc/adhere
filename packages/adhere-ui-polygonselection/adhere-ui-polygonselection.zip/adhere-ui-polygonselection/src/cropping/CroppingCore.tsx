import { Button, Card, Space } from 'antd';
import React, { forwardRef, memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ForwardRefRenderFunction } from 'react';

import FlexLayout from '@baifendian/adhere-ui-flexlayout';
import Intl from '@baifendian/adhere-util-intl';

import CircleDrawAction from '../draw/CircleDrawAction';
import DiamondDrawAction from '../draw/DiamondDrawAction';
import PolygonDrawAction from '../draw/PolygonDrawAction';
import RectangleDrawAction from '../draw/RectangleDrawAction';
import StartDrawAction from '../draw/StartDrawAction';
import TriangleDrawAction from '../draw/TriangleDrawAction';
import PolygonSelection from '../index.ts';
import CircleModifyAction from '../modify/CircleModifyAction';
import DiamondModifyAction from '../modify/DiamondModifyAction';
import PolygonModifyAction from '../modify/PolygonModifyAction';
import RectangleModifyAction from '../modify/RectangleModifyAction';
import StartModifyAction from '../modify/StartModifyAction';
import TriangleModifyAction from '../modify/TriangleModifyAction';
import { ActionEvents, PolygonSelectionActions, SelectType } from '../types';
import type {
  CroppingCoreAreaProps,
  CroppingCoreHandle,
  CroppingCoreProps,
  CroppingCoreToolProps,
  CroppingCoreWrapProps,
  IAction,
  IPolygonSelection,
  IStyle,
} from '../types';

const selectorPrefix = 'adhere-ui-cropping-core';

/**
 * CroppingCore
 * @param props
 * @param ref
 * @constructor
 */
const CroppingCore: ForwardRefRenderFunction<CroppingCoreHandle, CroppingCoreProps> = (
  { wrapProps, toolProps, areaProps },
  ref,
) => {
  const [type, setType] = useState<SelectType>(null);

  const [base64, setBase64] = useState<string>('');

  const areaRef = useRef<HTMLDivElement>();

  const polygonSelection = useRef<IPolygonSelection>();

  const curAction = useRef<IAction | null>(null);

  const inputFileFieldRef = useRef<HTMLInputElement>();

  const style: IStyle = {
    fillStyle: '#000',
    // 描边颜色
    strokeStyle: '#ccc',
    // 描边大小
    lineWidth: 2,
    lineCap: 'round',
    lineJoin: 'round',
    lineDash: [],
    lineDashOffset: -1,
    globalAlpha: 0.1,
  };

  /**
   * defaultProps
   */
  const defaultProps = useMemo<CroppingCoreWrapProps>(
    () => ({
      gutter: 20,
      wrapClassName: `${selectorPrefix}-wrap`,
    }),
    [],
  );

  /**
   * defaultLProps
   */
  const defaultLProps = useMemo<CroppingCoreToolProps>(
    () => ({
      fit: true,
    }),
    [],
  );

  /**
   * defaultCProps
   */
  const defaultCProps = useMemo<CroppingCoreAreaProps>(
    () => ({
      autoFixed: true,
    }),
    [],
  );

  /**
   * renderTool
   */
  const renderTool = useCallback(() => {
    const getType = (_type) => {
      return _type === type ? 'primary' : 'default';
    };

    const onClick = (_type) => {
      if (_type !== type) {
        setType(_type);
        polygonSelection.current.clearCanvasAll();
      }

      return _type !== type ? Promise.resolve() : Promise.reject();
    };

    return (
      <Card>
        <Space direction="vertical" size={20}>
          <input type="file" ref={inputFileFieldRef} accept="" style={{ display: 'none' }} />

          <Button
            block
            size="large"
            type="primary"
            onClick={() => {
              inputFileFieldRef.current?.click();
            }}
          >
            {Intl.v('打开')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Rectangle)}
            onClick={() =>
              onClick(SelectType.Rectangle).then(() => {
                curAction.current = new RectangleDrawAction();

                curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                  console.log('绘制开始前', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.DrawStart, (e) => {
                  console.log('绘制开始', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.Drawing, (e) => {
                  console.log('绘制中', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.DrawEnd, (e) => {
                  // curAction.current.start(data?.style);
                  console.log('绘制完成', JSON.stringify(e));
                });
                polygonSelection.current.changeAction(curAction.current as IAction);
                curAction.current.start(style);
              })
            }
          >
            {Intl.v('矩形剪裁')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Circle)}
            onClick={() =>
              onClick(SelectType.Circle)
                .then(() => {
                  curAction.current = new CircleDrawAction();

                  curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                    console.log('绘制开始前', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawStart, (e) => {
                    console.log('绘制开始', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.Drawing, (e) => {
                    console.log('绘制中', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawEnd, (e) => {
                    console.log('绘制完成', JSON.stringify(e));
                  });
                  polygonSelection.current.changeAction(curAction.current as IAction);
                  curAction.current.start(style);
                })
                .catch(() => {})
            }
          >
            {Intl.v('圆形剪裁')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Start)}
            onClick={() =>
              onClick(SelectType.Start).then(() => {
                curAction.current = new StartDrawAction();

                curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                  console.log('绘制开始前', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.DrawStart, (e) => {
                  console.log('绘制开始', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.Drawing, (e) => {
                  console.log('绘制中', JSON.stringify(e));
                });
                curAction.current.on(ActionEvents.DrawEnd, (e) => {
                  console.log('绘制完成', JSON.stringify(e));
                });
                polygonSelection.current.changeAction(curAction.current as IAction);
                curAction.current.start(style);
              })
            }
          >
            {Intl.v('五角星剪裁')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Triangle)}
            onClick={() =>
              onClick(SelectType.Triangle)
                .then(() => {
                  curAction.current = new TriangleDrawAction();

                  curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                    console.log('绘制开始前', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawStart, (e) => {
                    console.log('绘制开始', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.Drawing, (e) => {
                    console.log('绘制中', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawEnd, (e) => {
                    console.log('绘制完成', JSON.stringify(e));
                  });
                  polygonSelection.current.changeAction(curAction.current as IAction);
                  curAction.current.start(style);
                })
                .catch(() => {})
            }
          >
            {Intl.v('三角形剪裁')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Diamond)}
            onClick={() =>
              onClick(SelectType.Diamond)
                .then(() => {
                  curAction.current = new DiamondDrawAction();

                  curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                    console.log('绘制开始前', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawStart, (e) => {
                    console.log('绘制开始', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.Drawing, (e) => {
                    console.log('绘制中', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawEnd, (e) => {
                    console.log('绘制完成', JSON.stringify(e));
                  });

                  polygonSelection.current.changeAction(curAction.current as IAction);
                  curAction.current.start(style);
                })
                .catch(() => {})
            }
          >
            {Intl.v('菱形剪裁')}
          </Button>

          <Button
            block
            size="large"
            type={getType(SelectType.Polygon)}
            onClick={() =>
              onClick(SelectType.Polygon)
                .then(() => {
                  curAction.current = new PolygonDrawAction();

                  curAction.current.on(ActionEvents.DrawBeforeStart, (e) => {
                    console.log('绘制开始前', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawStart, (e) => {
                    console.log('绘制开始', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.Drawing, (e) => {
                    console.log('绘制中', JSON.stringify(e));
                  });
                  curAction.current.on(ActionEvents.DrawEnd, (e) => {
                    console.log('绘制完成', JSON.stringify(e));
                  });

                  polygonSelection.current.changeAction(curAction.current as IAction);
                  curAction.current.start(style);
                })
                .catch(() => {})
            }
          >
            {Intl.v('多边形剪裁')}
          </Button>
        </Space>
      </Card>
    );
  }, [type, toolProps]);

  /**
   * renderArea
   */
  const renderArea = useCallback(
    () => (
      <Card>
        <div className={`${selectorPrefix}-inner`} ref={areaRef}>
          {base64 ? (
            <>
              <img src={base64} alt="" />
              <div className={`${selectorPrefix}-inner-mask`}></div>
            </>
          ) : null}
        </div>
      </Card>
    ),
    [base64, areaProps],
  );

  /**
   * useEffect
   */
  useEffect(() => {
    polygonSelection.current = new PolygonSelection.PolygonSelection(areaRef.current);

    // ActionType
    const typeActionMap = new Map([
      [SelectType.Polygon, PolygonModifyAction],
      [SelectType.Circle, CircleModifyAction],
      [SelectType.Rectangle, RectangleModifyAction],
      [SelectType.Triangle, TriangleModifyAction],
      [SelectType.Diamond, DiamondModifyAction],
      [SelectType.Start, StartModifyAction],
    ]);

    polygonSelection.current.on(PolygonSelectionActions.CanvasClickGeometry, (data) => {
      // 多边形数据据
      // const d = {
      //   selectType: 'Polygon',
      //   actionType: 'Draw',
      //   data: {
      //     id: 'fd4ef30f-8add-4cc1-8f36-d861e77b5354',
      //     type: 'Polygon',
      //     data: [
      //       { x: 148.34375, y: 33 },
      //       { x: 120.34375, y: 198 },
      //       { x: 360.34375, y: 181 },
      //     ],
      //     style: {
      //       fillStyle: 'red',
      //       strokeStyle: '#000',
      //       lineWidth: 2,
      //       lineCap: 'round',
      //       lineJoin: 'round',
      //       lineDash: [],
      //       lineDashOffset: -1,
      //     },
      //   },
      // };
      //
      // polygonSelection.current.clearDraw();
      // polygonSelection.current.addHistoryData(d.data);
      // polygonSelection.current.drawHistoryData();
      //
      // const action = new PolygonModifyAction(d);
      // action.on(ActionEvents.End, () => {
      //   action.start();
      // });
      // polygonSelection.current.changeAction(action);
      // action.start();

      console.log('click');

      const Component = typeActionMap.get(data.type);

      const action = new Component({
        selectType: data.type,
        actionType: 'Draw',
        data,
      });

      action.on(ActionEvents.ModifyBeforeStart, (e) => {
        console.log('修改开始前', JSON.stringify(e));
      });
      action.on(ActionEvents.ModifyStart, (e) => {
        console.log('修改开始', JSON.stringify(e));
      });
      action.on(ActionEvents.Modifying, (e) => {
        console.log('修改中', JSON.stringify(e));
      });
      action.on(ActionEvents.ModifyEnd, (e) => {
        console.log('修改完成', JSON.stringify(e));
        action.start();
      });

      action.on(ActionEvents.Moving, (e) => {
        console.log('移动中', JSON.stringify(e));
      });
      action.on(ActionEvents.MoveEnd, (e) => {
        console.log('移动完成', JSON.stringify(e));
      });

      polygonSelection.current.changeAction(action);

      action.start();
    });

    polygonSelection.current.on(PolygonSelectionActions.CanvasClickEmpty, () => {
      console.log('clickEmpty');
      polygonSelection.current.clearDraw();
      polygonSelection.current.clearAssistDraw();
      polygonSelection.current.drawHistoryData();
    });
  }, []);

  useEffect(() => {
    const onChange = (e) => {
      const file = e.target.files[0];

      const read = new FileReader();
      read.onload = (e) => {
        setBase64(e.target?.result as string);
      };
      read.readAsDataURL(file);
    };

    inputFileFieldRef.current?.addEventListener('change', onChange);

    return () => {
      inputFileFieldRef.current?.removeEventListener('change', onChange);
    };
  }, []);

  return (
    <FlexLayout.TRBLC.LCLayout
      {...defaultProps}
      {...wrapProps}
      lProps={{
        ...defaultLProps,
        ...toolProps,
        render: renderTool,
      }}
      cProps={{
        ...defaultCProps,
        ...areaProps,
        render: renderArea,
      }}
    />
  );
};

const CroppingCoreHOC = memo(forwardRef<CroppingCoreHandle, CroppingCoreProps>(CroppingCore));

export default CroppingCoreHOC;
