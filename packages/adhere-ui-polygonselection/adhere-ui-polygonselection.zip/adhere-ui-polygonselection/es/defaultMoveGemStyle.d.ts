/**
 * 移动的元素样式
 */
declare const _default: {
    strokeStyle: string;
    lineWidth: number;
    lineDash: number[];
    lineDashOffset: number;
    globalAlpha: number;
};
export default _default;
