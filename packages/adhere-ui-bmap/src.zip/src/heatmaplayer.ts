import './heatmap';

/**
 * HeatMapLayer
 * @class HeatMapLayer
 * @classdesc 热力图
 */
// @ts-ignore
export default class extends BMapLib.HeatmapOverlay {}
